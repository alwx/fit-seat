# Running

* `npm install`
* `npm run serve`

# Libraries

* `vuex` (just like the idea and wanted to experiment with it)
* `scss` for styling
* `google-palette` for dynamic palette generation
